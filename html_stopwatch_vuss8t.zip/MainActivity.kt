package com.example.stopwatch

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
  private var minutes = 0
  private var seconds = 0
  private var milliseconds = 0
  private var isRunning = false
  private var handler: Handler? = null
  private val updateTimer = object : Runnable {
    override fun run() {
      milliseconds++
      if (milliseconds == 1000) {
        milliseconds = 0
        seconds++
        if (seconds == 60) {
          seconds = 0
          minutes++
        }
      }
      updateDisplay()
      handler?.postDelayed(this, 1)
    }
  }

  private fun updateDisplay() {
    val display = String.format("%02d:%02d:%03d", minutes, seconds, milliseconds)
    findViewById<TextView>(R.id.timer).text = display
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)

    val startBtn = findViewById<Button>(R.id.startBtn)
    val stopBtn = findViewById<Button>(R.id.stopBtn)
    val resetBtn = findViewById<Button>(R.id.resetBtn)

    startBtn.setOnClickListener {
      if (!isRunning) {
        isRunning = true
        startBtn.isEnabled = false
        stopBtn.isEnabled = true
        handler = Handler()
        handler?.postDelayed(updateTimer, 1)
      }
    }

    stopBtn.setOnClickListener {
      isRunning = false
      startBtn.isEnabled = true
      stopBtn.isEnabled = false
      handler?.removeCallbacks(updateTimer)
    }

    resetBtn.setOnClickListener {
      minutes = 0
      seconds = 0
      milliseconds = 0
      updateDisplay()
      isRunning = false
      startBtn.isEnabled = true
      stopBtn.isEnabled = false
      handler?.removeCallbacks(updateTimer)
    }

    updateDisplay()
    stopBtn.isEnabled = false
  }
}
