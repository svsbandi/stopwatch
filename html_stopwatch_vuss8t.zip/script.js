let minutes = 0;
let seconds = 0;
let milliseconds = 0;
let interval = null;
let isRunning = false;

const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const resetBtn = document.getElementById('resetBtn');

const minutesDisplay = document.getElementById('minutes');
const secondsDisplay = document.getElementById('seconds');
const millisecondsDisplay = document.getElementById('milliseconds');

function start() {
  if (!isRunning) {
    isRunning = true;
    startBtn.disabled = true;
    stopBtn.disabled = false;
    
    interval = setInterval(() => {
      milliseconds++;
      if (milliseconds === 1000) {
        milliseconds = 0;
        seconds++;
        if (seconds === 60) {
          seconds = 0;
          minutes++;
        }
      }
      updateDisplay();
    }, 1);
  }
}

function stop() {
  isRunning = false;
  startBtn.disabled = false;
  stopBtn.disabled = true;
  clearInterval(interval);
}

function reset() {
  minutes = 0;
  seconds = 0;
  milliseconds = 0;
  updateDisplay();
  stop();
  startBtn.disabled = false;
  stopBtn.disabled = true;
}

function updateDisplay() {
  minutesDisplay.textContent = String(minutes).padStart(2, '0');
  secondsDisplay.textContent = String(seconds).padStart(2, '0');
  millisecondsDisplay.textContent = String(milliseconds).padStart(3, '0');
}

startBtn.addEventListener('click', start);
stopBtn.addEventListener('click', stop);
resetBtn.addEventListener('click', reset);

// Initialize display
updateDisplay();
stopBtn.disabled = true;
